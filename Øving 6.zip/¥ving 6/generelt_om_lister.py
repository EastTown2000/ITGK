my_first_list = [1, 2, 3, 4, 5, 6]
print(my_first_list)

print(len(my_first_list))

my_first_list[-2] = 'pluss'
print(my_first_list)

my_second_list = my_first_list[-3:]
print(my_second_list)

print(my_second_list, 'er lik 10')