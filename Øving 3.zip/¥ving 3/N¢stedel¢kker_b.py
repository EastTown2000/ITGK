def klokkeslett():
    for time in range(24):
        for minutt in range(60):
            print(f'{time}:{minutt}')
        
klokkeslett()