def gangetabell():
    for tall_1 in range(1, 11):
        for tall_2 in range(1, 11):
            print(tall_1 * tall_2, end=' ')
        print()

gangetabell()