def fourth_char(str):
    return str[0::4]

st = "I Was Told There’d Be Cake"
print(fourth_char(st))