#Kodesnutt 1
# streng = "I Want Cake"
# streng[7:] = "Cupcake"
# print(streng)
# feil fordi du ikke kan sette inn noe med denne syntaxen

#Kodesnutt 2
streng = "I Want Cake"
streng = streng[-4:100:]
print(streng)
# korrekt men det er deffinitivt feil med 100 fra et lesbarhets perspektiv

#Kodesnutt 3
# streng = "I Want Cake"
# streng = streng[]
# print(streng)
# her er det syntax error