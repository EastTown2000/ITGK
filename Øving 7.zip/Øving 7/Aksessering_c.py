largestIndex = lambda str: len(str)-1

print(largestIndex('1234567890123'))