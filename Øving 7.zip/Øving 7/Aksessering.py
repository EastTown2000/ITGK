def printChar(a):
    for char in a: print(char)


printChar('olabukse')