import numpy as np

print(np.arange(1,16).reshape(3,5).transpose())