def divisable(a, b):
    return a % b == 0
